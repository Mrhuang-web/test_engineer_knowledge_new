
.. _reference-protocol-xml:

Xml
---

.. automodule:: spyne.protocol.xml
    :members:
    :show-inheritance:
    :undoc-members:
