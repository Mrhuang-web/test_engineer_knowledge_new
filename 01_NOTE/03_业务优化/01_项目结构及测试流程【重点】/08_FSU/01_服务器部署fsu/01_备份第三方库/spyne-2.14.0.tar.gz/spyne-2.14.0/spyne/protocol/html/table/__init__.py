
from spyne.protocol.html.table._base import HtmlTableBase
from spyne.protocol.html.table.row import HtmlRowTable
from spyne.protocol.html.table.column import HtmlColumnTable
