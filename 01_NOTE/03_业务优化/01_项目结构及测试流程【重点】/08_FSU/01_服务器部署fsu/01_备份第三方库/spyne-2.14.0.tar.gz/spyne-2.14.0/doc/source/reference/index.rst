
.. _reference-index:

====================
Spyne API Reference
====================

.. toctree::
    :maxdepth: 3

    base
    application
    service
    decorator
    error

    model/index
    interface
    protocol/index
    client
    server/index
    auxproc

    util
