
.. _reference-model-fault:

Fault
-----

.. autoclass:: spyne.model.fault.Fault
   :members:
   :show-inheritance:

