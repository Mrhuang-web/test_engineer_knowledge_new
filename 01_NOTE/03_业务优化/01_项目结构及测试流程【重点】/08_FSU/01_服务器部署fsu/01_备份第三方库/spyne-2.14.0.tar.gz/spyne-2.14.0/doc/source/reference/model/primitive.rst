
.. _reference-model-primitive:

Primitives
----------

.. automodule:: spyne.model.primitive
   :members:
   :show-inheritance:

