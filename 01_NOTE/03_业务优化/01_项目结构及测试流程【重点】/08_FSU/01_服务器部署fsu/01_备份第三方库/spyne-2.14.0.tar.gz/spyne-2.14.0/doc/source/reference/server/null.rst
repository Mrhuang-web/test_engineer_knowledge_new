
.. _reference-server-null:

NullServer
----------

.. automodule:: spyne.server.null
    :members:
    :inherited-members:
    :undoc-members:
