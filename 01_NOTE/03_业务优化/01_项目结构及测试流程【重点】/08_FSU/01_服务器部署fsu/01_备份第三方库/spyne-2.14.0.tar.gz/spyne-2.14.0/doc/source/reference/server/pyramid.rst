
.. _reference-server-pyramid:

Http (Pyramid)
--------------

.. automodule:: spyne.server.pyramid
    :members:
    :inherited-members:
    :undoc-members:
